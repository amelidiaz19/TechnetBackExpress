import EntidadRouter from "./Entidad.routes.js";

export const UsersRouter = {
  EntidadRouter,
};
