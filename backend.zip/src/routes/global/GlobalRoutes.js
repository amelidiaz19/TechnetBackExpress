import ArchivoRoutes from "./Archivo.routes.js";
import TipadoRoutes from "./Tipado.routes.js";

export const GlobalRoutes = {
  ArchivoRoutes,
  TipadoRoutes,
};
